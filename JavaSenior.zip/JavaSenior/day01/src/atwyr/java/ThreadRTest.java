package atwyr.java;

/**
 * 程序：一段静态的代码
 * 进程：正在运行的一个程序
 * 线程：一个程序内部的一条执行路径
 * 每个线程拥有自己独立的栈、程序计数器 ——多个线程共享一个进程的结构：方法区、堆
 *
 * @author MoZiqing
 * @create 2021-11-25 8:47
 */
class MyThreadR implements Runnable{
    private int i = 10000;

    public MyThreadR() {

    }


    public void run(){
        for (int i = 0; i < 10000; i++) {
            if (i%2 == 0)
                System.out.println(Thread.currentThread().getName() + ":" + i );
        }

    }
}

public class ThreadRTest {
    public static void main(String[] args) {
        MyThreadR r = new MyThreadR();
        Thread q1 = new Thread(r);
        Thread q2 = new Thread(r);
        Thread q3 = new Thread(r);

        q1.start();
        q2.start();
        q3.start();

    }

}
