package atwyr.exer;

/**
 * @author MoZiqing
 * @create 2021-11-24 21:16
 */
class MyThread1 extends Thread{

    @Override
    public void run(){
        for (int i = 0;i < 10000; i++){
            if (i % 2 == 0){
                System.out.println(Thread.currentThread().getName() + ":" + i);
            }
        }
    }
}

class MyThread2 extends Thread{

    @Override
    public void run(){
        for (int i = 0;i < 10000; i++){
            if (i % 2 != 0){
                System.out.println("*****" + Thread.currentThread().getName() + ":" + i);
            }
        }
    }
}

public class ThreadDemo {
    public static void main(String[] args) {
        MyThread1 d1 = new MyThread1();
        MyThread2 d2 = new MyThread2();


        d2.start();
        d1.start();

    }
}
