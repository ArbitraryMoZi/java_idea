package com.atwyr.exer;

import org.junit.Test;

/**出现次数
 * @author MoZiqing
 * @create 2021-12-19 22:38
 */
public class StringDemo1 {
    /**
     *
     * @param mainStr 总的
     * @param subStr 需查找的
     * @return
     */

    public int getCount(String mainStr, String subStr){
        int mainLength = mainStr.length();
        int subLength = subStr.length();
        int count = 0;
        int index;
        if (mainLength >= subLength){
            /*indexof返回指定子字符串第一次出现的字符串中的索引。*/
            while ((index = mainStr.indexOf(subStr)) != -1){
                count++;
                /*返回一个字符串，该字符串是此字符串的子字符串。*/
                mainStr = mainStr.substring(index + subStr.length());
            }

            return count;
        }else {
            return 0;
        }
    }

    @Test
    public void  testGetCount(){
        String mainstr = "asf";
        String substr = "aqsasfwerdaswasfzxswsfasf";
        int i = getCount(substr,mainstr);
        System.out.println(i);
    }
}
